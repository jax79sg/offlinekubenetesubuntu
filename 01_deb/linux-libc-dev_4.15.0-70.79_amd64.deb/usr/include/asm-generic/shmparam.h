/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ASM_GENERIC_SHMPARAM_H
#define __ASM_GENERIC_SHMPARAM_H

#define SHMLBA PAGE_SIZE	 /* attach addr a multiple of this */

#endif /* _ASM_GENERIC_SHMPARAM_H */
